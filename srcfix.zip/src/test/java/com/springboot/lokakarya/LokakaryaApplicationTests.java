package com.springboot.lokakarya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LokakaryaApplicationTests {

	@Test
	void contextLoads() {
	}

}
