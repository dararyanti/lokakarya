package com.ogya.lokakarya.nasabah.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogya.lokakarya.nasabah.entity.HistoryTelkom;

public interface HistoryTelkomRepository extends JpaRepository<HistoryTelkom, Long>{

}
