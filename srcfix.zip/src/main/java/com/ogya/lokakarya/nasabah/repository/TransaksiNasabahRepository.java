package com.ogya.lokakarya.nasabah.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogya.lokakarya.nasabah.entity.MasterBank;
import com.ogya.lokakarya.nasabah.entity.TransaksiNasabah;

public interface TransaksiNasabahRepository extends JpaRepository<TransaksiNasabah, Long>{
	TransaksiNasabah findByMasterBank (MasterBank masterBank);

}
