package com.ogya.lokakarya.nasabah.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogya.lokakarya.nasabah.entity.MasterBank;

public interface MasterBankRepository extends JpaRepository<MasterBank, Long> {
}
