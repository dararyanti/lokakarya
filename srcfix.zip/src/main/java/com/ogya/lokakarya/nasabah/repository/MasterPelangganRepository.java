package com.ogya.lokakarya.nasabah.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogya.lokakarya.nasabah.entity.MasterPelanggan;

public interface MasterPelangganRepository extends JpaRepository<MasterPelanggan, Long>{
	MasterPelanggan findByNoTelp (Long noTelpon);
	
}
