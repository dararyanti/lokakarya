package com.ogya.lokakarya.nasabah.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogya.lokakarya.nasabah.entity.HistoryBank;

public interface HistoryBankRepository extends JpaRepository<HistoryBank, Long>{

}
