package com.ogya.lokakarya.nasabah.wrapper;

import java.util.Date;

public class HistoryBankWrapper {
	private Long idHistoribnk;
	private Date tanggal;
	private Long norek;
	private Byte statusKet;
	private String nama;
	private Long uang;
	private Long norekDituju;
	private Long noTlp;
	
	public Long getIdHistoribnk() {
		return idHistoribnk;
	}
	public void setIdHistoribnk(Long idHistoribnk) {
		this.idHistoribnk = idHistoribnk;
	}
	public Date getTanggal() {
		return tanggal;
	}
	public void setTanggal(Date tanggal) {
		this.tanggal = tanggal;
	}
	public Long getNorek() {
		return norek;
	}
	public void setNorek(Long norek) {
		this.norek = norek;
	}
	public Byte getStatusKet() {
		return statusKet;
	}
	public void setStatusKet(Byte statusKet) {
		this.statusKet = statusKet;
	}
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	public Long getUang() {
		return uang;
	}
	public void setUang(Long uang) {
		this.uang = uang;
	}
	public Long getNorekDituju() {
		return norekDituju;
	}
	public void setNorekDituju(Long norekDituju) {
		this.norekDituju = norekDituju;
	}
	public Long getNoTlp() {
		return noTlp;
	}
	public void setNoTlp(Long noTlp) {
		this.noTlp = noTlp;
	}
	
	
}
