package com.ogya.lokakarya.nasabah.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "MASTER_PELANGGAN")
public class MasterPelanggan {
	private Long idPelanggan;
	private String nama;
	private Long noTelp;
	private String alamat;
	private Long userId;

	@Id
	@GeneratedValue(generator = "MASTER_PELANGGAN_GEN", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "MASTER_PELANGGAN_GEN", sequenceName = "MASTER_PELANGGAN_SEQ", initialValue = 1, allocationSize = 1)
	public Long getIdPelanggan() {
		return idPelanggan;
	}

	public void setIdPelanggan(Long idPelanggan) {
		this.idPelanggan = idPelanggan;
	}

	@Column(name = "NAMA")
	public String getNama() {
		return nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	@Column(name = "NO_TELP")
	public Long getNoTelp() {
		return noTelp;
	}

	public void setNoTelp(Long noTelp) {
		this.noTelp = noTelp;
	}

	@Column(name = "ALAMAT")
	public String getAlamat() {
		return alamat;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}

	@Column(name = "USER_ID")
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
