package com.ogya.lokakarya.nasabah.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.ogya.lokakarya.nasabah.entity.MasterPelanggan;
import com.ogya.lokakarya.nasabah.entity.TransaksiTelkom;

public interface TransaksiTelkomRepository extends JpaRepository<TransaksiTelkom, Long>{
	
	Optional<TransaksiTelkom> findByMasterPelangganAndStatus(MasterPelanggan masterPelanggan, Integer status);
	TransaksiTelkom findByMasterPelanggan(MasterPelanggan masterPelanggan);
	
	@Query(value = "SELECT * FROM TRANSAKSI_TELKOM WHERE ID_PELANGGAN = :idPelanggan", nativeQuery = true)
	List<TransaksiTelkom> findByTagihanPelanggan(@Param("idPelanggan") Long idPelanggan);
	
	@Query(value = "SELECT SUM(UANG) FROM TRANSAKSI_TELKOM WHERE ID_PELANGGAN = :idPelanggan AND STATUS = 1", nativeQuery = true)
	Long tagihanTelpon (@Param("idPelanggan") Long idPelanggan);
	
	@Query(value = "SELECT STATUS FROM TRANSAKSI_TELKOM WHERE ID_PELANGGAN = :idPelanggan", nativeQuery = true)
	List<Integer> statusTagihan (@Param("idPelanggan") Long idPelanggan);

}
