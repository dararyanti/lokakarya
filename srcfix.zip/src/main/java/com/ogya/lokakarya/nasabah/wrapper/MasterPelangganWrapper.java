package com.ogya.lokakarya.nasabah.wrapper;

public class MasterPelangganWrapper {
	private Long noTelepon;
	private Long idPelanggan;
	private String namaPelanggan;
	private Long tagihan;
	
	public Long getNoTelepon() {
		return noTelepon;
	}
	public void setNoTelepon(Long noTelepon) {
		this.noTelepon = noTelepon;
	}
	public Long getIdPelanggan() {
		return idPelanggan;
	}
	public void setIdPelanggan(Long idPelanggan) {
		this.idPelanggan = idPelanggan;
	}
	public String getNamaPelanggan() {
		return namaPelanggan;
	}
	public void setNamaPelanggan(String namaPelanggan) {
		this.namaPelanggan = namaPelanggan;
	}
	public Long getTagihan() {
		return tagihan;
	}
	public void setTagihan(Long tagihan) {
		this.tagihan = tagihan;
	}
}
